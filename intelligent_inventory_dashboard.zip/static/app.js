let products = [];
let historyChart = null;
let forecastChart = null;

async function loadProducts(){
  const q = document.getElementById("search").value;
  products = await fetch("/api/products?q=" + encodeURIComponent(q)).then(r=>r.json());

  const select = document.getElementById("productSelect");
  select.innerHTML = products.map(p =>
    `<option value="${p.product_id}">${p.product_id} — ${p.product_name}</option>`
  ).join("");

  const tbody = document.querySelector("#productTable tbody");
  tbody.innerHTML = products.map(p => `
    <tr>
      <td>${p.product_id}</td>
      <td>${p.product_name}</td>
      <td>${p.category}</td>
      <td>${p.subcategory}</td>
      <td>${p.brand}</td>
      <td>₹${Number(p.price).toLocaleString()}</td>
    </tr>`).join("");

  if(products.length) refreshDashboard();
}

async function refreshDashboard(){
  const id = document.getElementById("productSelect").value;
  if(!id) return;

  const product = products.find(p=>p.product_id===id);
  document.getElementById("pname").textContent = product.product_name;
  document.getElementById("pid").textContent = product.product_id;
  document.getElementById("category").textContent = product.category;
  document.getElementById("subcategory").textContent = product.subcategory;
  document.getElementById("brand").textContent = product.brand;
  document.getElementById("price").textContent = "₹" + Number(product.price).toLocaleString();

  const [rec, hist, forecast, events] = await Promise.all([
    fetch(`/api/recommendation/${id}`).then(r=>r.json()),
    fetch(`/api/history/${id}`).then(r=>r.json()),
    fetch(`/api/forecast/${id}`).then(r=>r.json()),
    fetch("/api/events").then(r=>r.json())
  ]);

  document.getElementById("stock").textContent = rec.current_stock.toLocaleString();
  document.getElementById("rop").textContent = rec.reorder_point.toLocaleString();
  document.getElementById("order").textContent = rec.suggested_order_qty.toLocaleString();
  document.getElementById("action").textContent = rec.action;
  document.getElementById("supplierMini").textContent = rec.supplier;

  document.getElementById("daily").textContent = rec.daily_demand + " units";
  document.getElementById("lead").textContent = rec.lead_time_days + " days";
  document.getElementById("safety").textContent = rec.safety_stock + " units";
  document.getElementById("moq").textContent = rec.min_order_qty + " units";
  document.getElementById("unitcost").textContent = "₹" + rec.unit_cost.toLocaleString();
  document.getElementById("ordervalue").textContent = "₹" + rec.estimated_order_value.toLocaleString();

  document.getElementById("supplier").textContent = rec.supplier;
  document.getElementById("port").textContent = rec.port;
  document.getElementById("lead2").textContent = rec.lead_time_days + " days";
  document.getElementById("moq2").textContent = rec.min_order_qty + " units";
  document.getElementById("unitcost2").textContent = "₹" + rec.unit_cost.toLocaleString();

  document.getElementById("events").innerHTML = events.map(e => `
    <div class="event">
      <b>${e.event}</b>
      <div>${e.months}</div>
      <small>Impact: ${e.impact} • Factor: ${e.factor}</small>
    </div>`).join("");

  drawHistory(hist);
  drawForecast(forecast);
}

function drawHistory(data){
  if(historyChart) historyChart.destroy();
  const step = Math.max(1, Math.floor(data.length / 30));
  const sampled = data.filter((_,i)=>i%step===0);
  historyChart = new Chart(document.getElementById("historyChart"),{
    type:"line",
    data:{labels:sampled.map(x=>x.date),datasets:[{
      label:"Weekly demand",
      data:sampled.map(x=>x.demand),
      tension:.25,
      borderWidth:2,
      pointRadius:1
    }]},
    options:{responsive:true,plugins:{legend:{display:true}},scales:{y:{beginAtZero:false}}}
  });
}

function drawForecast(data){
  if(forecastChart) forecastChart.destroy();
  forecastChart = new Chart(document.getElementById("forecastChart"),{
    type:"line",
    data:{labels:data.map(x=>x.date),datasets:[{
      label:"Forecast units",
      data:data.map(x=>x.forecast),
      tension:.25,
      borderWidth:2
    }]},
    options:{responsive:true,plugins:{legend:{display:true}},scales:{y:{beginAtZero:false}}}
  });
}

loadProducts();
